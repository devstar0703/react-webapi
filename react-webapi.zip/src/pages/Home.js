import * as React from 'react' ;

import TopSection from 'src/components/Home/TopSection';

const Home = () => {
    return (
        <>
            <TopSection />
        </>
    )
}

export default Home ;