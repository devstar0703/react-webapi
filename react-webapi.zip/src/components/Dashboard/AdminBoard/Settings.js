import * as React from 'react' ;

const Settings = () => {
    return (
        <>
        </>
    )
}

export default Settings;