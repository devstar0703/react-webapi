import tagStyled from 'styled-components';

export const ContentView = tagStyled.div`
    padding: 40px;
`