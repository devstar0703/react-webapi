export { default as TabView } from "./TabView";
export { default as PhoneForm } from "./PhoneForm";
export { default as BeautyEditor } from "./BeautyEditor";