export const backend_endpoint = 'http://10.10.18.15:8080/' ;

export const ADMIN_ROLE = "admin" ;
export const USER_ROLE = "user" ;