const ActionTypes = {
    ConnectWallet : "ConnectWallet"
}

export default ActionTypes ;